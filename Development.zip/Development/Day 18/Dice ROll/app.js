function rollDice(){
  let rand = Math.floor((Math.random()*6)+1);
  console.log(rand);
}

rollDice();