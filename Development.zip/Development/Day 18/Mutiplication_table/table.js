function printtable(n){
  for(let i = 1;i<=10;i++){
    console.log(n + " * "+ i + " = "+ n*i);

  }

  

}
let a = prompt("Enter Number");
printtable(a);