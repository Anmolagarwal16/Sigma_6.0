let str = ["hi", "hrllo", "bye", "!"];

function concat(str) {
  let result = "";

  for (let i = 0; i < str.length; i++) {
    result = result + str[i];
  }

  return result;
}

console.log(concat(str)); // Output: "hihrllobye!"
 v