function hello(){
  console.log("hello");
}
hello();



function isAdult(){
  let age = 13;
  if(age>=18){
    console.log("adult");
  }
  else{
    console.log("Minor");
  }
}

isAdult();