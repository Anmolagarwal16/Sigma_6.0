function average(a,b,c){
  console.log("The average is: " + Math.floor((a + b + c) / 3));
}
if (isNaN(a) || isNaN(b) || isNaN(c)) {
  console.log("Please enter valid numbers.");
} else {
  average(a, b, c);
}
a = parseInt(prompt());
b = parseInt(prompt());
c = parseInt(prompt());