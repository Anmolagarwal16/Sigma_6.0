let btns = document.querySelectorAll("button");
console.dir(btns);

function sayHello() {
  alert("Hello");
}

function sayName() {
  console.log("Anmol Agarwal");
}

for (let btn of btns) {
  btn.onclick = function() {
    sayHello();
    sayName();
  };
}
