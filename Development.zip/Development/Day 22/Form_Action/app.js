 let form = document.querySelector("form");

    form.addEventListener("submit", function(event) {
      event.preventDefault();
      let user = document.querySelector("#user");
      let pass = document.querySelector("#pass");
      alert(`Hi ${user.value}, your password was set to ${pass.value}`);
    });

    let user = document.querySelector("#user");
    let pass = document.querySelector("#pass");

    user.addEventListener("change", function() {
      console.log("Username changed");
      console.log("final value =", user.value);
    });

    pass.addEventListener("input", function() {
      console.log("input changed");
      console.log("final value =", pass.value);
    });

      console.log("final value =", pass.value);
