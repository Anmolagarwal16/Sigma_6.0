
let input = document.querySelector("input");
let b = "";
input.addEventListener("keydown",function(e){
  console.log("key pressed");
  let a = e.key;
  console.log(a);
  console.log(e.code);
})