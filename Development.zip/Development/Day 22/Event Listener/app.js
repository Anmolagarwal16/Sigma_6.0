let btns = document.querySelectorAll("button");
console.dir(btns);

function sayHello() {
  alert("Hello");
}

function sayName() {
  alert("Anmol Agarwal");
}

for (let btn of btns) {
  // btn.onclick = function() {
  //   sayHello();
  //   sayName();
  // };

  btn.addEventListener("click",sayHello);
  btn.addEventListener("click",sayName)
}
