// let img = document.querySelector('img');
// console.log(img);


// let heading = document.querySelector('h1')


let para1 = document.createElement('p');
para1.innerText = "Hey I am Red!";

document.querySelector("body").append(para1);
para1.classList.add("red");



let h3 = document.createElement('h3');
h3.innerText = "Hey I am BLue! h3";

document.querySelector("body").append(h3);
h3.classList.add("blue");


let div = document.createElement("div")
let h1 = document.createElement("h1")
let para3 = document.createElement("p");

h1.innerText = "I am in a Div";
para3.innerText = "ME TOO!";


div.append(h1)
div.append(para3)

div.classList.add("box");

document.querySelector("body").append(div);








































// // // let smallImages = document.getElementsByClassName("oldImg");

// // // for(let i = 0;i<smallImages.length;i++){
// // //   smallImages[i].src="assets/spiderman_img.png";
// // //   console.log(`value of image no ${i} is changed.`);
// // // }\


// // // let a = document.getElementsByTagName("p");
// // // console.log(a);


// // // let a = document.querySelector('h1');
// // // let b = document.querySelector('#description');
// // // let c= document.querySelector(".oldImg");
// // // let d = document.querySelectorAll("div a");

// // // console.log(a);
// // // console.log(b);
// // // console.log(c);
// // // console.log(d);


// // let img = document.querySelector('img');
// // console.log(img);
// // let a = img.getAttributeimg('id');
// // console.log(a);

// // let b = img.setAttribute('src',"assests/creation_1.png");



