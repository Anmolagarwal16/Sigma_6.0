let gameSeq = [];
let userSeq = [];

let btns = ["yellow","red","purple","green"];

let started = false;
let level = 0;

let h2 = document.querySelector("h2");


document.addEventListener("keypress",function(){
  if(started == false){
  console.log("Game is Started");
  started = true;
  levelup();
  }
});

function gameFlash(btn){
  btn.classList.add("Flash");     // <-- white when game flashes
  setTimeout(function(){
    btn.classList.remove("Flash");
  },250);
}

function userFlash(btn){
  btn.classList.add("userFlash"); // <-- green when user clicks
  setTimeout(function(){
    btn.classList.remove("userFlash");
  },250);
}


function levelup(){
  level++;
  h2.innerText = `Level ${level}`;

  let randInx = Math.floor(Math.random()*3);
  let randColor = btns[randInx];
  let randbtn = document.querySelector(`.${randColor}`);

  gameSeq.push(randColor);
  console.log(gameSeq);
  // console.log(randInx);
  // console.log(randColor);
  gameFlash(randbtn);

}

function btnPress(){
  let btn = this;
  console.log(this);
  userFlash(btn);
}

let allBtns = document.querySelectorAll(".btn");
for(btn of allBtns){
  btn.addEventListener("click",btnPress);
}