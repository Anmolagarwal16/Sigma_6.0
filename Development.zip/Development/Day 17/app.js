const max = prompt("Enter a Max Number");
// alert("hii");
// console.log(max);

const random = Math.floor(Math.random() * max)+1;
let guess = prompt('Guess the Number');

while(true){
  if(guess == "quit"){
    console.log('User Quit');
    break;
  }

  if(guess == random){
    console.log("You are Right! congrats !!");
    break;
  } else if(guess < random){
    guess = prompt("Hint : Your guess was too samall. Please try again");
  } else if(guess > random){
    guess = prompt("Hint : Your guess was too Big. Please try again");
  }
  // } else {
  //   guess = prompt("Your guess waas Wrong. Please Try again");
  // }
}