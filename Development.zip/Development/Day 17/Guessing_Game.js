const user = prompt("Enter a number (upper limit):");
console.log("Upper limit:", user);

const random = Math.floor(Math.random() * user) + 1;
console.log("Random number generated (for debugging):", random);

let guess = prompt("Guess the number!");

while (true) {
  if (guess === "quit") {
    console.log("User quit the game.");
    break;
  }

  // Convert guess to a number for proper comparison
  guess = Number(guess);

  if (guess === random) {
    console.log("🎉 You are right!");
    break; // <-- stop the loop when guessed correctly
  } 
  else if (guess < random) {
    guess = prompt("Hint: Your guess was too small. Try again or type 'quit' to exit.");
  } 
  else {
    guess = prompt("Hint: Your guess was too large. Try again or type 'quit' to exit.");
  }
}
