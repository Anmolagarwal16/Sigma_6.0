for(let i = 0;i<10;i++){
let num = Math.random();
num = num*10;
num = Math.floor(num);
num = num+1;
console.log(num);
} 