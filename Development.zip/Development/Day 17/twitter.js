const post = {
  username: "@anmol",
  content : "This is my post",
  likes : 150,
  reposts: 5,
  tags: ["anmol","lalit","ayush"]
}
// console.log(post);
// console.log(typeof(post));
// console.log(post["likes"])


let prop = "reposts";
console.log[post.prop];
console.log[post[prop]];