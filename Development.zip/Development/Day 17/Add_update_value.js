const student = {
  name:"anmol",
  age:34,
  marks:45.5,
  city:"hapur"
}
console.log(student.city)
student.city = "hapur";
console.log(student);

student.gender = "female";
console.log(student);

delete student.marks;

console.log(student);