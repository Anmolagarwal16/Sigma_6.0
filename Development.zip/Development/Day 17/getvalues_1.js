const obj = {
  1 :'a',
  2: 'b',
  null : "d",
  true:"c",
  undefined:"e"

}

console.log(obj);
console.log([1]);
console.log(obj[undefined]);