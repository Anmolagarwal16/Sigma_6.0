
for(let i = 0;i<100;i++){
let num = Math.random();
num = num*100;
num = Math.floor(num);
num = num+1;
console.log(num);
}

for(let i = 0;i<100;i++){
let num = Math.random();
num = num*5;
num = Math.floor(num);
num = num+21;
console.log(num);
}