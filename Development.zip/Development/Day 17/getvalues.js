let student = {
  name:"shradha",
  marks:94.4
}
console.log(student.name)
