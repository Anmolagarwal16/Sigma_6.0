const classinfo = [
  {
    name: "anmol",
    grade:"A+",
    city:"delhi"
  },
  {
    name:"ayush",
    grade:"b+",
    city:"chennai"
  },
  {
    name : "lalit",
    grade:"A",
    city:"hapur"
  }
]

console.log(classinfo);
console.log(classinfo[0]);
console.log(classinfo[1]);
console.log(classinfo[2]);
console.log(classinfo[1].city);
classinfo[1].city="Gurugaon";
console.log(classinfo[1]);