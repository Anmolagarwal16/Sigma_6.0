const classinfo = {
  anmol:{
    grade:"A+",
    city:"delhi"
  },
  ayush:{
    grade:"b+",
    city:"chennai"
  },
  lalit:{
    grade:"A",
    city:"hapur"
  }
}

console.log(classinfo);
console.log(classinfo.anmol);
console.log(classinfo.lalit.city);