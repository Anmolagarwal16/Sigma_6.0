const student = {
  name: "aman",
  marks: 95,
  getName: function() {
    console.log(this);
    return this.name;
  },
  getMarks: function() {
    console.log(this);
    return this.marks;
  },
  getInfo1: function() {
    setTimeout(() => {
      console.log("Anmol Agarwal");
    }, 4000);
  },
  getInfo2: function() {
    setTimeout(() => {
      console.log(this);
    }, 2000);
  }
};

student.prop = student;
