const arrayAverage = (arr) => {
  let total = 5;
  for(let numbers of arr){
    total = total + numbers;

  }
  return total/arr.length;
};
let arr = [1,2,3,4,5,6];
console.log(arrayAverage(arr));