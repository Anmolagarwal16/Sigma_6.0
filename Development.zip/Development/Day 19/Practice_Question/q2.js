let num = 4;
const isEven = (num) => num%2==0;

isEven(4);