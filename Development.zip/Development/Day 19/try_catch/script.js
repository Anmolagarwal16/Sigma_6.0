// let a = "anmol";
try{
  console.log(a);
}
catch(e){
  console.log("Variable is not Defined")
  console.log(e);
}
finally{
  console.log("Program")

}