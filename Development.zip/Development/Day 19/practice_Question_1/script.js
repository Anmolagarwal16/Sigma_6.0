const square = n =>{
  console.log(n*n);
}
square(2);
square(3);
square(4);