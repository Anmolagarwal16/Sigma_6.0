setInterval ( () =>{
  console.log("Anmol Agarwal");
},70);