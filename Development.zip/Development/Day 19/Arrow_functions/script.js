const sum = (a,b)=> {
  console.log(a+b);
}

const cube = n => {
  console.log(Math.pow(n,3));
}
const power =  (a,b) => {
  console.log(Math.pow(a,b))
}

const hello = () =>{
  console.log("Hello World");
}