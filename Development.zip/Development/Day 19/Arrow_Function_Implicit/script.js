const mul = (a,b) => (
  a*b
);

console.log(mul(3,4));
