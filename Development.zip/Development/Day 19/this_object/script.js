const Student = {
  name: "shradha",
  age: 23,
  eng: 95,
  math: 93,
  phy: 97,
  getAvg() {
    let avg = (this.eng + this.math + this.phy)/3;
    console.log(avg);
    console.log(`${this.name}`);
  }
};

function getAvg(){
  console.log(this);
}

Student.getAvg(); // Works fine
getAvg();         // Logs global object or undefined
