console.log("Hi There");

setTimeout(() => {
  console.log("Anmol Agarwal")
}, 4000);

console.log("Welcome")