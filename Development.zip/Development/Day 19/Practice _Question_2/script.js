// // Write a Function that prints "Hell0 World" 5 times at interval of 2s Each


// let id = setInterval(()=>{
//   console.log("Hell0 World");
// }, 2000);
 
// setTimeout(() => {
//   clearInterval(id);
//   console.log("Kaam Khatam");
// },10000);


function printHelloNTimes(n, interval) {
  let count = 0;
  const id = setInterval(() => {
    console.log("Hello World");
    count++;
    if (count === n) {
      clearInterval(id);
      console.log("Kaam Khatam");
    }
  }, interval);
}

printHelloNTimes(5, 2000);
