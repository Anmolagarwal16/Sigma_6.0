let num = [1,2,3,4];

let a = num.some((el) => {
  return el%2==0;
})
console.log(a);