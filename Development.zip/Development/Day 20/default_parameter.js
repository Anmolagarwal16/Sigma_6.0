function sum(a = 1,b){
  return a+b;
}
console.log(sum(1,2));
console.log(sum(undefined,3));