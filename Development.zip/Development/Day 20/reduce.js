let nums = [1,2,3,4];
let finalVal = nums.reduce((res, element) => {
  return res + element;
});
console.log(finalVal);