let arr =  [1,2,3,4,5,6,1,2,4,5,6,3,8,9];

let a = Math.min(...arr); // value individual jaayegi no need to create individual argumments

arr.push(-1);

console.log(a);
a = Math.min(...arr);
console.log(a);
console.log(..."anmolagarwal16");



let arr1 = ["anmol","ayush","abhishek"];
let arr2 = [...arr1];
console.log(arr2);

let arr3 = [...arr];
console.log(arr3);


let data = {
  email:"anmolagrval9917@gmail.com",
  password:"crazyxyz",
};

let datacopy = {...data, id:123};
console.log(datacopy);

let ob = {...arr};
console.log(ob);

let obj1 = {..."This is a String convert into an object."};
console.log(obj1);

