// let num = [1, 2, 3, 4];

// let a = num.every((el) => el % 2 == 0);

// console.log(a);
let num = [1, 2, 3, 4];
let num2 = [2,4,6,8];

let a = num.every((el) => el % 2 == 0);
let b = num2.every((el) => el % 2 == 0);

console.log(a);
console.log(b);
