let arr = [{
  name: "aman",
  marks: 95
},
{
  name:"ayush",
  marks:94.4
},
{
  name:"auu",
  marks:12
}
];

arr.forEach((student) => {
  console.log(student.marks);
});


// let arr = [1,2,3,4,5];

// arr.forEach(function(el){
//   console.log(el);
// });

// arr.forEach(function (el){
//   console.log(el);
// });



// // let print = function(el){
// //   console.log(el);
// //   }

// // arr.forEach(print);