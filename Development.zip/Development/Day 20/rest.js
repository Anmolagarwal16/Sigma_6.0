function sum(...args) {
  return args.reduce((total, n) => total + n, 0);
}

console.log(sum(5, 10, 15)); // 30
