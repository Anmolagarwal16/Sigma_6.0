// let num =[1,2,3,4];

// let double = num.map((el)=>{
// return el*el;
// });

// console.log(double);

// let num = [1, 2, 3, 4];

// let double = num.map((el) => {
//   return el * el;
// });

// console.log(double);


let arr = [{
  name: "aman",
  marks: 95
},
{
  name:"ayush",
  marks:94.4
},
{
  name:"auu",
  marks:12
}
];

let gpa = arr.map((el) => {
  return el.marks/10;
});

console.log(gpa);