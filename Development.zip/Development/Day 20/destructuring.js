let names = ["tony","brue","peter","stever","a"];
let[winner,runnerup,second_runnerup,...others] = names;
console.log(winner);
console.log(others);
console.log(second_runnerup);



const student = {
  name: "karan",
  age:14,
  class:9,
  subjects:["hindi","english","maths"],
  username:"karan@123",
  password:"abcd",
  city:"pune",
};

let{username:user, password:secret,city = "mumbai"} =  student;

console.log(user);
console.log(secret);
console.log(city);