let nums = [10, 20, 30, 40];

let a = nums.every((el) => {
  return el % 10 == 0;
});

console.log(a); // true

function getMin() {
  let min = nums.reduce((min, e) => {
    if (min < e) {
      return min;
    } else {
      return e;
    }
  });
  return min;
}

console.log(getMin());
